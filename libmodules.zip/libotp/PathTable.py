import math
import sys
import platform
import os
class PathTable:

	def __init__():
		pass