import math
import sys
import platform
import os
class Settings:

	def __init__():
		pass