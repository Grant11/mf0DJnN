import math
import sys
import platform
import os
class CMoverGroup:

	def __init__():
		pass