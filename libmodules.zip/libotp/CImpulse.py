import math
import sys
import platform
import os
class CImpulse:

	def __init__():
		pass