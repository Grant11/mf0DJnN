import math
import sys
import os
import platform
import time

class PosHpr:

	def __init__(self):
		pass