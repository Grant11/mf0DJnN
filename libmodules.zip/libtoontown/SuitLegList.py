import math
import sys
import os
import platform
import time

class SuitLegList:

	def __init__(self):
		pass