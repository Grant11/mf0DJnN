import math
import sys
import os
import platform
import time

import CPetBrain
import PosHpr

class CPetFlee:

	def __init__(self):
		pass