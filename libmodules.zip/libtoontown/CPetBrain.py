import math
import sys
import os
import platform
import time

class CPetChase:

	def __init__(self):
		pass