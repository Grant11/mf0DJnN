class DNAError(Exception):
    pass