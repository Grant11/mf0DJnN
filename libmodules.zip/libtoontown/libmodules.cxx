// Filename: libmodules.cxx
// Writen by: Nick

[('DtoolClassDict', {'DtoolClassDict': {...}, 'isAttendingUs': 
<method 'isAttendingUs' of 'libtoontown.CPetBrain' objects>, '__setattr__': 
<slot wrapper '__setattr__' of 'libtoontown.CPetBrain' objects>,
 '__new__': <built-in method new of type object at 0x6091C2C0>, 'this_metatype': 
 <member 'this_metatype' of 'libtoontown.CPetBrain' objects>, 'this': 
 <member 'this' of 'libtoontown.CPetBrain' objects>, 'CPetBrain': 
 <type 'libtoontown.CPetBrain'>, '__getattribute__': 
 <slot wrapper '__getattribute__' of 'libtoontown.CPetBrain' objects>, 
 '__delattr__': <slot wrapper '__delattr__' of 'libtoontown.CPetBrain' objects>, 
 '__doc__': None, '__init__': <slot wrapper '__init__' of 'libtoontown.CPetBrain' objects>}), 
 ('isAttendingUs', <method 'isAttendingUs' of 'libtoontown.CPetBrain' objects>),
 ('__setattr__', <slot wrapper '__setattr__' of 'libtoontown.CPetBrain' objects>), 
 ('__new__', <built-in method new of type object at 0x6091C2C0>), 
 ('this_metatype', <member 'this_metatype' of 'libtoontown.CPetBrain' objects>), 
 ('this', <member 'this' of 'libtoontown.CPetBrain' objects>), 
 ('CPetBrain', <type 'libtoontown.CPetBrain'>), ('__getattribute__', 
 <slot wrapper '__getattribute__' of 'libtoontown.CPetBrain' objects>), 
 ('__delattr__', <slot wrapper '__delattr__' of 'libtoontown.CPetBrain' objects>), 
 ('__doc__', None), ('__init__', <slot wrapper '__init__' of 'libtoontown.CPetBrain' objects>)]
<method 'buildGraph' of 'libtoontown.DNALoader' objects>
[('DNACornice', <type 'libtoontown.DNACornice'>), 
('DNAVisGroup', <type 'libtoontown.DNAVisGroup'>), 
('CSYupRight', 2), 
'CPetChase', <type 'libtoontown.CPetChase'>), 
('DNASuitPoint', <type 'libtoontown.DNASuitPoint'>), 
('DNAInteractiveProp', <type 'libtoontown.DNAInteractiveProp'>), 
('Dtool_PyNativeInterface', 1), 
('DNALandmarkBuilding', <type 'libtoontown.DNALandmarkBuilding'>), 
('PosHpr', <type 'libtoontown.PosHpr'>), ('DNAFlatDoor', <type 'libtoontown.DNAFlatDoor'>), 
('Dtool_AddToDictionary', <built-in function Dtool_AddToDictionary>), 
('DNAWall', <type 'libtoontown.DNAWall'>), 
('DNABattleCell', <type 'libtoontown.DNABattleCell'>), 
('DNAFlatBuilding', <type 'libtoontown.DNAFlatBuilding'>), 
('DNASignText', <type 'libtoontown.DNASignText'>), 
('DNASign', <type 'libtoontown.DNASign'>), 
('DNAGroup', <type 'libtoontown.DNAGroup'>),
 ('loadDNAFileAI', <built-in function loadDNAFileAI>), 
 ('Dtool_BorrowThisReference', <built-in function Dtool_BorrowThisReference>), 
 ('CSDefault', 0), ('DNAWindows', <type 'libtoontown.DNAWindows'>),
 ('DNASignBaseline', <type 'libtoontown.DNASignBaseline'>), 
 ('CSZupRight', 1), ('getDnaPath', <built-in function getDnaPath>),
 ('__doc__', None), ('DNADoor', <type 'libtoontown.DNADoor'>),
 ('CSInvalid', 5), ('DNAStorage', <type 'libtoontown.DNAStorage'>), 
 ('__file__', 'C:\\Users\\Nicholas\\Desktop\\Nicholas\\Computer\\Desktop\\Nicholas\\Computer\\ToontownOnline\\libtoontown.dll'), 
 ('CPetBrain', <type 'libtoontown.CPetBrain'>), 
 ('loadDNAFile', <built-in function loadDNAFile>), 
 ('DNAAnimProp', <type 'libtoontown.DNAAnimProp'>),
 ('SuitLeg', <type 'libtoontown.SuitLeg'>), 
 ('DNASuitPath', <type 'libtoontown.DNASuitPath'>), 
 ('DNAAnimBuilding', <type 'libtoontown.DNAAnimBuilding'>), 
 ('__name__', 'libtoontown'), ('SuitLegList', <type 'libtoontown.SuitLegList'>), 
 ('CSZupLeft', 3), ('DNASignGraphic', <type 'libtoontown.DNASignGraphic'>), 
 ('DNAData', <type 'libtoontown.DNAData'>), ('DNAStreet', <type 'libtoontown.DNAStreet'>), 
 ('CPetFlee', <type 'libtoontown.CPetFlee'>), ('CSYupLeft', 4), 
 ('DNANode', <type 'libtoontown.DNANode'>), ('DNAProp', <type 'libtoontown.DNAProp'>), 
('DNASuitEdge', <type 'libtoontown.DNASuitEdge'>), 
('DNALoader', <type 'libtoontown.DNALoader'>)]